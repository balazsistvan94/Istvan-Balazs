<nav class="top-nav">
    <ul>
        <li>
            <a href="<?php echo URLROOT; ?>/index">Acasa</a>
        </li>
        <li>
            <a href="#Despre">Despre Noi</a>
        </li>
        <li>
            <a href="<?php echo URLROOT; ?>/posts">Articole</a>
        </li>
        <li>
            <a href="#Contact">Contact</a>
        </li>
        <li class="btn-login">
            <?php if(isset($_SESSION['user_id'])) : ?>
                <a href="<?php echo URLROOT; ?>/users/logout">Deconecteaza-te</a>
            <?php else : ?>
                <a href="<?php echo URLROOT; ?>/users/login">Conecteaza-te</a>
            <?php endif; ?>
        </li>
    </ul>
</nav>
