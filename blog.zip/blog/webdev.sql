-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2022 at 02:37 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.2.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdev`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `body`, `created_at`) VALUES
(2, 1, 'Articol1', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit molestiae impedit, aliquid vel dolore ratione velit delectus, eligendi accusantium repudiandae assumenda sed qui ad nesciunt a error dicta. Est adipisci eveniet qui odit, quos dolorum quidem commodi id voluptates vitae optio, numquam ex quaerat veniam et a accusantium ullam molestias harum officia ut, vero non totam? Molestiae repudiandae magnam veniam ipsum perferendis nisi et in, esse numquam officia tempore velit aliquam veritatis earum ipsam eligendi facilis modi blanditiis, facere minima?', '0000-00-00 00:00:00'),
(3, 1, 'Articol2', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente minus neque ullam numquam est harum, rerum a adipisci labore laborum id totam dolorem omnis exercitationem iste dignissimos fuga nobis mollitia ducimus blanditiis soluta? Nihil iste voluptas est neque eos minima minus ad voluptates. Sunt dolore laudantium rerum qui. Repudiandae, at!', '0000-00-00 00:00:00'),
(4, 1, 'Articol3', 'oivjrhvfwnekmwd,2kojiknwhebngvkfmcled,wd3kmjrwevfed', '0000-00-00 00:00:00'),
(5, 1, 'wde', 'fwdew', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'balazsistvan', 'Balazsistvan205@gmail.com', '$2y$10$8MT5g.CUNA3eO3ngu6fIV.yxrfvwkr7fGEXDVKEz0xtZpjRvs0cYu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
