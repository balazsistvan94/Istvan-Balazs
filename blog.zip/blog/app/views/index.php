<?php
   require APPROOT . '/views/includes/head.php';
?>
<div id="section-landing">
    <?php
       require APPROOT . '/views/includes/navigation.php';
    ?>

    <div class="wrapper-landing containerHome">
        <h1>Blog</h1>
        <h2>Balazs Istvan</h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus officiis aliquid laborum a cum alias non ratione similique ullam sint ut quasi at, ad quos dolorum voluptatem harum officia aliquam optio quas totam. Nisi laboriosam odit velit nesciunt veniam praesentium rem, modi blanditiis quis quisquam earum quod iusto. Magnam ducimus, nostrum voluptatem, corrupti quos animi pariatur ipsa magni eum autem nemo modi similique odit. Magnam, nobis mollitia rerum repudiandae similique eveniet in facilis deleniti expedita excepturi molestias dolore dolor natus ipsa voluptatibus? Facere, dolorum ipsa consectetur beatae consequatur vel, qui libero similique quod dolores, commodi ducimus impedit distinctio in aspernatur iusto reprehenderit temporibus officia minima nesciunt unde iste deleniti. Molestiae voluptatibus libero deserunt, iusto adipisci necessitatibus incidunt voluptate reiciendis exercitationem quisquam ipsam quos laborum ad minima perspiciatis debitis illum possimus velit quis at iste? Suscipit soluta cupiditate corporis in? Ex distinctio nam est magni numquam obcaecati dicta! Sit dolores voluptatibus recusandae voluptas, accusantium dolorum officiis libero accusamus, quo enim neque quos hic ea aliquid consectetur sapiente aspernatur fuga nesciunt aperiam asperiores, assumenda ducimus. Unde nobis tempora quod fugiat, nisi cum commodi magni cumque? Adipisci tempore assumenda ad placeat minima quis amet odio, dolore laborum. Accusantium rem fugiat cum, ipsa voluptatibus tempora assumenda saepe suscipit earum maxime qui, exercitationem est quo molestiae doloribus natus dolorem! Earum dolor illum iste nam, reprehenderit distinctio facere aperiam cupiditate saepe. Quasi ratione optio similique laborum? Eius quaerat dolor excepturi repellat debitis eos nulla quasi, molestiae minus veritatis ad commodi at nostrum magni sequi vel delectus quisquam. Impedit perspiciatis aliquam, quia illo accusantium maxime iste, libero, vitae tempora cum et perferendis recusandae? Non quos deserunt itaque, inventore odit dignissimos quo. Harum voluptate nesciunt facere reiciendis quidem pariatur atque id ea doloremque expedita maiores omnis reprehenderit vero hic exercitationem provident in explicabo, illum cum quis sed aliquam cupiditate rerum. Eius velit nihil optio iure quaerat fugiat architecto quae est expedita non. Facilis modi quasi eligendi hic sint! Tempore sint modi blanditiis illum? Perferendis numquam quidem inventore quo soluta temporibus architecto tempora est error ipsa omnis veniam sunt molestias amet culpa, dolor rerum consectetur nemo id atque ut voluptates rem reprehenderit? Maxime, rerum nemo fugit exercitationem error modi explicabo unde quod! Delectus sit, corporis, ea dolores, doloribus totam consequatur consequuntur nostrum libero maiores velit. Vitae sint quaerat vero veniam velit animi odio laudantium cum, accusamus praesentium tenetur dolore quisquam perspiciatis, dolor expedita totam illum perferendis cupiditate voluptate! Nisi nobis nesciunt esse ad culpa non odio pariatur, consequuntur repellendus quae dolorum unde voluptatibus quis beatae obcaecati veniam optio dolore cumque voluptatum ex, saepe impedit provident! Quae tenetur atque consequatur, odio quas impedit optio culpa maiores sapiente soluta labore quasi et, officiis iste sit! Incidunt modi, molestias harum non, nihil libero sit ratione enim ad laboriosam vel voluptate ex? Veritatis asperiores veniam dolore sint ut explicabo placeat, accusantium id iusto nisi maiores aspernatur repellat necessitatibus ab aperiam, dolorem dicta eligendi laboriosam exercitationem blanditiis eaque soluta. Reiciendis quos dolor quam ipsam ex ad fuga recusandae culpa! Beatae repudiandae illum totam eveniet.</p>
        <div id="Despre">
        <h1>Despre Noi</h1>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Explicabo excepturi nisi quam, quo ad tempore numquam vel odit illum commodi alias tenetur dolor pariatur facilis repudiandae architecto praesentium deserunt corporis quae quaerat obcaecati voluptate. Asperiores et nisi debitis veniam optio voluptatibus repellendus, commodi enim dolorem animi est nobis aut accusantium dolore neque in dolorum natus rem cupiditate obcaecati impedit possimus quisquam alias atque! Quod sunt nisi veniam dolorem? Officia quasi alias saepe molestias. Ad adipisci iste sapiente aut at, voluptatum deleniti sequi. Inventore, vero asperiores soluta sapiente officia fuga a sequi eos optio perferendis ducimus est cupiditate eaque. Itaque hic fugit labore amet dolores, deleniti eveniet enim voluptates ut autem est mollitia. Enim sunt blanditiis illo et expedita? Dolor aliquam, id quod possimus rerum optio cum doloremque labore quam voluptas, voluptatibus cumque corrupti laudantium eum veritatis porro minus adipisci ipsam? Qui excepturi vitae laudantium nihil quasi! Eveniet quam aliquam necessitatibus doloribus quisquam adipisci optio, error iste quo doloremque praesentium minima repudiandae ut totam quod mollitia sit a ducimus excepturi? Aperiam eligendi aut et corporis pariatur architecto, possimus, id repellendus laudantium explicabo, eum asperiores. Eaque nesciunt delectus deserunt voluptatum et mollitia enim aspernatur aliquid. Veniam atque possimus reprehenderit eum! Dolorum, enim cupiditate. Facere quod quaerat labore voluptate reiciendis a ipsam natus laudantium amet! In porro sequi eum laboriosam quidem saepe, eveniet nisi maiores possimus quasi est similique. Provident molestiae numquam impedit illo eum, quos obcaecati aut itaque expedita, sit quia facilis velit culpa perspiciatis corrupti enim, vitae aspernatur officia atque odit maxime? Soluta ipsam laboriosam, animi accusantium modi exercitationem nulla sunt id sapiente consequatur nemo eius ad, quisquam nesciunt magnam officia repellendus doloribus neque quod esse nisi amet accusamus laborum facere? Minus cum illum repudiandae maxime adipisci distinctio error placeat nesciunt, asperiores pariatur, rem quae sed quis nemo sint obcaecati, esse rerum ipsum nihil sit voluptatum recusandae. Beatae blanditiis, non in veniam laudantium et quam facilis officia nesciunt doloremque, eius iste inventore earum atque aliquam. Facere, maiores, quo repellat distinctio quos perferendis rerum accusantium excepturi adipisci perspiciatis pariatur placeat exercitationem. Explicabo, accusamus eaque. Eos dicta veritatis mollitia deleniti animi eaque, laborum ipsum ut rerum at asperiores illum tenetur beatae dolores rem est impedit labore libero. Eius facere in ab distinctio adipisci? Autem quasi vitae ipsa aspernatur unde reprehenderit voluptatum dignissimos facere eligendi, doloribus delectus iure illo deserunt odit quaerat quae molestias, necessitatibus asperiores laudantium accusantium, non distinctio corporis amet error. Iusto, expedita. Alias sint voluptatum ab officiis, dicta iusto vero ex accusantium fugiat, dolores quo perferendis incidunt itaque laboriosam impedit aut quidem quam suscipit quas, ipsa deleniti architecto blanditiis. Exercitationem laboriosam dolor voluptatibus libero dolorem animi unde maxime itaque, illo, nulla totam numquam ullam consectetur veniam provident eos nemo cumque asperiores debitis, id non quos laudantium commodi! Animi ipsa eos, sapiente numquam voluptas vero cumque molestiae iste esse tempora soluta quisquam doloribus eum labore repudiandae nihil corrupti quam nisi provident? Nulla velit consectetur quo debitis error molestias deserunt, rem maiores itaque vero amet beatae aliquid quae voluptates ut reprehenderit modi molestiae?</p>
        </div>
        <div id="Contact">
        <h1>Contact</h1>
        <div class="containerContact">
  <form>

    <label for="fname">Nume</label>
    <input type="text" id="fname" name="firstname" placeholder="Numele tau..">

    <label for="lname">Prenume</label>
    <input type="text" id="lname" name="lastname" placeholder="Prenumele tau..">

    <label for="country">Tara</label>
    <select id="country" name="country">
      <option value="romania">Romania</option>
      <option value="hungary">Hungary</option>
      <option value="usa">USA</option>
    </select>

    <label for="subject">Subiect</label>
    <textarea id="subject" name="subject" placeholder="Scrie aici mesajul tau.." style="height:200px"></textarea>

    <input type="submit" value="Trimite">

  </form>
</div>
        </div>
    </div>
</div>
