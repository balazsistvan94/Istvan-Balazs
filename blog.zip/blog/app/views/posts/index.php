<?php
   require APPROOT . '/views/includes/head.php';
?>

<div class="navbar dark">
    <?php
       require APPROOT . '/views/includes/navigation2.php';
    ?>
</div>

<div class="container">
    <?php if(isLoggedIn()): ?>
        <a class="btn green" href="<?php echo URLROOT; ?>/posts/create">
            Creaza o postare
        </a>
    <?php endif; ?>

    <?php foreach($data['posts'] as $post): ?>
        <div class="container-item">
            <?php if(isset($_SESSION['user_id']) && $_SESSION['user_id'] == $post->user_id): ?>
                <a
                    class="btn orange"
                    href="<?php echo URLROOT . "/posts/update/" . $post->id ?>">
                    Actualizeaza
                </a>
                <form action="<?php echo URLROOT . "/posts/delete/" . $post->id ?>" method="POST">
                    <input type="submit" name="delete" value="Sterge" class="btn red">
                </form>
            <?php endif; ?>
            <h2 class="postTitle">
                <?php echo $post->title; ?>
            </h2>

            <h3 class="postInfo">
                <?php echo 'Creat la: ' . date('F j h:m', strtotime($post->created_at)) ?>
            </h3>

            <p class="postContent">
                <?php echo $post->body ?>
            </p>
        </div>
    <?php endforeach; ?>
</div>
