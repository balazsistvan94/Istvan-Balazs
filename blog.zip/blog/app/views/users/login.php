<?php
   require APPROOT . '/views/includes/head.php';
?>

<div class="navbar">
    <?php
       require APPROOT . '/views/includes/navigation.php';
    ?>
</div>

<div class="container-login">
    <div class="wrapper-login">
        <h2>Conecteaza-te</h2>

        <form action="<?php echo URLROOT; ?>/users/login" method ="POST">
            <input class="login" type="text" placeholder="Nume utilizator *" name="username">
            <span class="invalidFeedback">
                <?php echo $data['usernameError']; ?>
            </span>

            <input type="password" placeholder="Parola *" name="password">
            <span class="invalidFeedback">
                <?php echo $data['passwordError']; ?>
            </span>

            <button id="submit" type="submit" value="submit">Trimite</button>

            <p class="options">Nu ai inca cont? <a href="<?php echo URLROOT; ?>/users/register">Inregistreaza-te!</a></p>
        </form>
    </div>
</div>
