<?php
    //Parametri DB
    define('DB_HOST', 'localhost'); //Host
    define('DB_USER', 'root'); // Username db
    define('DB_PASS', ''); //Parola db
    define('DB_NAME', 'webdev'); //Nume db

    //APPROOT
    define('APPROOT', dirname(dirname(__FILE__)));

    //URLROOT (Linkuri dinamice)
    define('URLROOT', 'http://localhost/blog');

    //Nume site
    define('SITENAME', 'Blog - Balazs Istvan');
